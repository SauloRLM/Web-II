---
title: Angular y Scully
description: Cómo construir un blog con Angular y Scully
published: true
---

# Angular y Scully
Angular es un framework de javascript robusto que podemos usar para crear aplicaciones web excelentes y de alto rendimiento.
Scully es un popular generador de sitios web estaticos que potencia Angular con caracteristicas Jamstack.
- https://angular.io
- https://scully.io
- https://www.jamstack.org